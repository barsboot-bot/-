﻿=========================================================================
  Uness ("унесённые") — ассеты носителей музыки
  кассета · MiniDisc · карта памяти          версия 1.0.0
=========================================================================

Что лежит в архиве
------------------
1_MODELS/     геометрия: .obj + .mtl. Единицы — МЕТРЫ, оси как в
              Object Builder: X — вправо, Y — в глубину, Z — вверх.
              Импортировать с МАСШТАБОМ 1.0 (не 0.001!).
2_TEXTURES/   исходники текстур: 45 PNG = 15 материалов x 3 карты
              (_co — цвет, _nohq — нормали, _smdi — блики).
              PNG нарисованы скриптом: никаких стоковых картинок,
              лицензия чистая.
3_MATERIALS/  готовые .rvmat (15 шт.) — они уже лежат в паке мода,
              сюда скопированы для справки и для Object Builder.
4_PREVIEW/    чертежи .svg с размерами, контрольные рендеры моделей,
              контактный лист всех текстур.
5_IN_GAME/    config.cpp — образец классов носителей (в репозитории уже
              применён) и types_uness_assets.xml — лут для новых предметов.
docs/         полная пошаговая инструкция (17_ASSETS.md).
tools/        генераторы исходников + REBUILD_ASSETS.bat.

Откуда это взялось (пути в репозитории)
---------------------------------------
1_MODELS/    <- Models/src/
2_TEXTURES/  <- Models/tex_src/
3_MATERIALS/ <- @Uness/Addons/Uness_Data/data/tex/
4_PREVIEW/   <- Models/preview/
5_IN_GAME/   <- @Uness/Addons/Uness_Data/config.cpp, server_files/mpmissions/
tools/       <- tools/


ТРИ ШАГА (нужны Windows + DayZ Tools из Steam)
----------------------------------------------

ШАГ 1. Текстуры PNG -> .paa (TexView 2)
   Открыть PNG из 2_TEXTURES -> File -> Save As:
     тип файла : PaC (DirectX)      (это и есть .paa)
     имя       : СОХРАНЯЕМ суффикс  (_co / _nohq / _smdi)
     папка     : @Uness\Addons\Uness_Data\data\tex\
     сжатие    : _co = DXT1, _nohq = DXT5, _smdi = DXT1
     mipmaps   : ВКЛЮЧИТЬ
   Всего 45 файлов. Быстрее — пакетный режим: File -> Batch Convert,
   три прохода (сначала все _co, потом _nohq, потом _smdi).

ШАГ 2. Модели .obj -> .p3d (Object Builder)
   File -> Import -> Wavefront (.obj) -> файл из 1_MODELS:
     * масштаб 1.0;
     * проверить габарит по чертежу из 4_PREVIEW;
     * материалы назначать ФАЙЛАМИ .rvmat из 3_MATERIALS (не .paa!),
       тогда нормали и блики подхватятся сами;
     * LOD-схема: Resolution 0.000, Geometry (коробка по габариту),
       View Geometry (копия корпуса), Memory (точка ce_center),
       Shadow Volume 0.000;
     * Save As -> @Uness\Addons\Uness_Data\data\ue_cassette.p3d
       (и так же ue_minidisc.p3d, ue_memorycard.p3d — имена ровно как
       в config.cpp).
   Иконка инвентаря — там же: Export -> Icon.

ШАГ 3. Сборка
   powershell -ExecutionPolicy Bypass -File build.ps1
   В игре: #spawnitem UE_Item_Cassette_Rock
           #spawnitem UE_Item_MiniDisc_Classic
           #spawnitem UE_Item_MemoryCard


Классы предметов и габариты
---------------------------
UE_Item_Cassette_Rock, UE_Item_Cassette_Pop     100.0 x 63.8 x 12.0 мм
UE_Item_MiniDisc_Rock, _Pop, _Classic, _Dance    68.0 x 72.0 x  5.0 мм
UE_Item_MemoryCard                               32.0 x 24.0 x  2.1 мм

Селекшены моделей: shell, label, window, cavity, hub_left/right,
tape_left/right (кассета); shell, shutter, disc, hub, label, cavity (MD);
shell, label, contacts, switch (карта). Подробно — Models_README.md.


ВАЖНО
-----
* В архиве НЕТ .p3d и .paa, и это не упущение: ODOL и PaC — бинарные
  форматы Bohemia, их пишут только родные инструменты. Скриптом такой
  файл не создаётся. Всё, что можно подготовить до сохранения, —
  подготовлено.
* PNG внутрь PBO класть нельзя: движок их не читает, только вес растёт.
  В пак идут .paa (из шага 1) и .rvmat.
* У всех кассет ОДИН меш: обложка альбома подменяется материалом через
  селекшен `label` (см. config.cpp, hiddenSelectionsMaterials[]).
  Новый альбом = новая обложка + новый класс, модель не меняется.

Полная инструкция, чек-лист и «грабли» — docs/17_ASSETS.md
