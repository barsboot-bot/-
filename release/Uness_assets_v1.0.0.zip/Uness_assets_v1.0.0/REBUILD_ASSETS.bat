@echo off
rem ============================================================
rem  Uness - rebuild asset sources (models, textures, materials)
rem  Needs Python 3 and Pillow/numpy. Run from the archive root.
rem ============================================================
setlocal
echo == Uness assets rebuild ==

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: python not found in PATH. Install Python 3 and retry.
    pause
    exit /b 1
)

echo [1/5] installing Pillow and numpy...
python -m pip install --user pillow numpy
if errorlevel 1 (
    echo WARNING: pip install failed - trying to continue anyway.
)

echo [2/5] geometry (.obj + .mtl + drafts)...
python tools\make_models.py
if errorlevel 1 goto fail

echo [3/5] textures (.png: _co/_nohq/_smdi + album covers)...
python tools\make_textures.py
if errorlevel 1 goto fail

echo [4/5] materials (.rvmat)...
python tools\make_rvmat.py
if errorlevel 1 goto fail

echo [5/5] preview renders + integrity check...
python tools\render_preview.py
python tools\check_assets.py
if errorlevel 1 goto fail

echo.
echo DONE. Sources are in 1_MODELS, 2_TEXTURES, 3_MATERIALS.
echo Next: convert PNG to .paa (TexView 2) and OBJ to .p3d (Object Builder).
pause
exit /b 0

:fail
echo.
echo FAILED - see the message above.
pause
exit /b 1
